package Model;

import Interfaces.Entrenable;

public class RedNeuronal extends Modelo implements Entrenable {
    private int maxCapas;
    
    public RedNeuronal(String nombre, String laboratorio, TipoDatos tipoDatos, int maxCapas) {
        super(nombre, laboratorio, tipoDatos);
        this.maxCapas = maxCapas;
    }

    @Override
    public String detallesEspecificos() {
        return " Capas maximas = " + maxCapas;
    }

    @Override
    public void entrenar() {
        System.out.println("Entrenando red neuronal con el nombre: " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + detallesEspecificos();
    }
    
    
}
