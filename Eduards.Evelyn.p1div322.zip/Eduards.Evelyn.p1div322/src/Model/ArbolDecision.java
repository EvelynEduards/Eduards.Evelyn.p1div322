package Model;

import Interfaces.Entrenable;

public class ArbolDecision extends Modelo implements Entrenable {
    private String criterioDivision;

    public ArbolDecision(String nombre, String laboratorio, TipoDatos tipoDatos,String criterioDivision) {
        super(nombre, laboratorio, tipoDatos);
        this.criterioDivision = criterioDivision;
    }
    
    

    @Override
    public String detallesEspecificos() {
        return " Criterio de division = " + criterioDivision;
    }

    @Override
    public void entrenar() {
        System.out.println("Entrenando Arbol de decision con el nombre: " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + detallesEspecificos();
    }
    
    
}
