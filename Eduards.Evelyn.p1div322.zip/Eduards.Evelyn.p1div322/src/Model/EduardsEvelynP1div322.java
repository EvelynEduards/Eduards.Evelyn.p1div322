package Model;


public class EduardsEvelynP1div322 {

    public static void main(String[] args) {
        SistemaModelos sistema = new SistemaModelos();
        cargarModelos(sistema);
        
     //Mostrar modelos
     sistema.mostrarModelos();
     
     //Entrenar modelos
     sistema.entrenarModelos();
     
     //Filtrar por tipo de dato
     sistema.filtrarPorTipoDatos(TipoDatos.DATOS_NUMERICOS);
        
        
        
    }
    
    public static void cargarModelos(SistemaModelos sistema){
    sistema.agregarModelo(new RedNeuronal("Clasificador de Imagenes", "Lab1", TipoDatos.DATOS_NUMERICOS, 10));
    sistema.agregarModelo(new RedNeuronal("Analizador de texto", "Lab2", TipoDatos.DATOS_TEXTUALES, 8));
    sistema.agregarModelo(new ArbolDecision("Riesgo", "Lab3", TipoDatos.DATOS_NUMERICOS, "gini"));
    sistema.agregarModelo(new ArbolDecision("ClasificadorSpam", "Lab2", TipoDatos.DATOS_TEXTUALES, "entropia"));
    sistema.agregarModelo(new AlgoritmoGenetico("Optimizador genetico", "Lab1", TipoDatos.DATOS_NUMERICOS, 5.5));
    
    //Para que tire error:
    //sistema.agregarModelo(new RedNeuronal("Clasificador de Imagenes", "Lab1", TipoDatos.DATOS_NUMERICOS, 10));
    
    }
}
