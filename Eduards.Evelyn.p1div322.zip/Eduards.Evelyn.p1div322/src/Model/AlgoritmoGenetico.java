package Model;

public class AlgoritmoGenetico extends Modelo {
    private double tasaMutacion;

    public AlgoritmoGenetico(String nombre, String laboratorio, TipoDatos tipoDatos,double tasaMutacion) {
        super(nombre, laboratorio, tipoDatos);
        this.tasaMutacion = tasaMutacion;
    }

    @Override
    public String detallesEspecificos() {
       return " Tasa de mutacion: " + tasaMutacion + "%";
    }

    @Override
    public String toString() {
        return super.toString() + detallesEspecificos();
    }
    
    
    
    
    
    
}
