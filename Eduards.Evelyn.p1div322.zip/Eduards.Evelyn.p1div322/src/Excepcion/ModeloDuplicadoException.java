package Excepcion;

public class ModeloDuplicadoException extends RuntimeException {
    
    private static final String MENSAJE = "Modelo duplicado";
   
    public ModeloDuplicadoException() {
    super(MENSAJE);
    }

    
    public ModeloDuplicadoException(String msg) {
        super(msg);
    }
}

  